# FullStack Store Ratings

Minimal full-stack project (Express backend + React frontend).

See instructions in the conversation.
