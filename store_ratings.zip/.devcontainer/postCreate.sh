#!/usr/bin/env bash
set -e
echo 'Installing deps...'
cd backend || exit 0
npm install --silent || true
cd ../frontend || exit 0
npm install --silent || true
echo 'Done.'
